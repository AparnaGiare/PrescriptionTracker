"use strict";
var Pharmacy = (function () {
    function Pharmacy() {
    }
    return Pharmacy;
}());
exports.Pharmacy = Pharmacy;
//# sourceMappingURL=pharmacy.js.map