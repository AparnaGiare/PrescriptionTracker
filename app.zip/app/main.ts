import { platformBrowserDynamic} from '@angular/platform-browser-dynamic';

import { AppModule } from './app.module';
//import { bootstrap }  from '@angular/platform-browser-dynamic';
platformBrowserDynamic().bootstrapModule(AppModule);

//import {Angular2Progressbar} from './progressbar.example';

//bootstrap(Angular2Progressbar);


